import React from 'react';
import LandingPage from './components/Landing-Page/landing'


function App() {
  return (
    <div className="App">
      <LandingPage/>
    </div>
  );
}

export default App;
